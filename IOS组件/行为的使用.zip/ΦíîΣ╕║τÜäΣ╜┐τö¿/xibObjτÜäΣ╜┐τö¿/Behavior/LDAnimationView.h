//
//  LDAnimationView.h
//  xibObj的使用
//
//  Created by yh on 16/8/22.
//  Copyright © 2016年 ld. All rights reserved.
//

#import "LDBehavior.h"

@interface LDRotationView : LDBehavior

@property (nonatomic, weak) IBOutlet UIView * animationView;

@end
