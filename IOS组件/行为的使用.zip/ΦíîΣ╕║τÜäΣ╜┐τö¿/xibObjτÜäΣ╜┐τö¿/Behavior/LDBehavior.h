//
//  LDBehavior.h
//  Behavior的使用
//
//  Created by yh on 16/8/22.
//  Copyright © 2016年 ld. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LDBehavior : UIControl
@property(nonatomic, weak) IBOutlet id owner;
@end
